package bean;

 



public class Account {
	public enum accountType{
		SAVINGS,CURRENT;
	}
	
	private static int account_no=1000;
	private accountType account_type;
	private double account_balance;
	 private String transactionDetails=""; 
	
	public Account()
	{
		super();
		account_no++;
	}
	
	public Account(String type, double ac_balance) {
		super();
		account_no++;
		
		this.account_balance = ac_balance;
		this.account_type = accountType.valueOf(type.toUpperCase());
	}


	public int getAc_no() {
		return account_no++;
	}


	public accountType getType() {
		return account_type;
	}


	public void setType(accountType type) {
		this.account_type = type;
	}
	public String getTransactionDetails() {
        return transactionDetails;
    }
	 public void setTransactionDetails(String transactionDetails) {
         this.transactionDetails = this.transactionDetails+" "+transactionDetails+"\n";
     }


	public double getAccount_balance() {
		return account_balance;
	}


	public void setAccount_balance(double ac_balance) {
		this.account_balance = ac_balance;
	}
	
	public void setAccount_no(int num)

	{
		this.account_no = num;
	}
	@Override
	public String toString() {
		return "account_no=" + account_no + "\ntype=" + account_type + "\naccount_balance=" + account_balance + "";
	}
	
	
}