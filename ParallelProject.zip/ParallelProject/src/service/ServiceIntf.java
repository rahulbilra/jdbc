package service;
import bean.Customer;
public interface ServiceIntf {

	public void createAccount(Customer c);
	public Customer showBal(int ac_no) throws Exception;
	Customer deposit(int ac_no ,double amt);
	Customer withdraw(int ac_no , double amt);
	void fundTransfer(int ac1 , int ac2 , double amt);
	public Customer getDetails(int key);
}
